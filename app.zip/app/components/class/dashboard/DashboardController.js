'use strict';

angular.module('Dashboard')

  .controller('DashboardController',
    ['$scope', function ($scope) {

    }]);
