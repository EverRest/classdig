angular.module('classDigApp')

.controller('LoginController', function ($scope) {
    console.log("Error AUTH");
});

