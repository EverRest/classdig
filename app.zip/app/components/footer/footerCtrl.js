// angular.module("classDigApp").directive("footer", function() {
//   return {
//     restrict: 'A',
//     templateUrl: 'app/components/footer/footer.html',
//     scope: true,
//     transclude : false,
//     controller: ['$scope', '$filter', function ($scope, $filter) {
//       // Your behaviour goes here :)
//
//     }]
//   };
// });
