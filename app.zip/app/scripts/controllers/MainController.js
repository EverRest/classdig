'use strict';

/**
 * @ngdoc function
 * @name classApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the classDigApp
 */

angular.module('classDigApp')

  .controller( 'MainController',['$rootScope', 'AuthenticationService', function ($rootScope, AuthenticationService) {

  }]);
